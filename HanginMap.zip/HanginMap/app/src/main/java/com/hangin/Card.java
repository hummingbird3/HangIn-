package com.hangin;
import java.util.*;

/**
 * Created by USER1 on 30.04.2017.
 */

public class Card {

    // properties

    String poster;
    Time time;
    Area location;
    int numHanging;
    ArrayList<Person> hangingPeople;
    int numComing;
    ArrayList<Person> comingPeople;
    boolean privat;
    Group visibleGroups;


    // constructors

    // methods
}
