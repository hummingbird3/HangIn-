/**
 * Created by USER1 on 30.04.2017.
 */
package com.hangin;
public class Board {
}
